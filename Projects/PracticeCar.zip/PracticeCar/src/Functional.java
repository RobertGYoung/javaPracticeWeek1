
public interface Functional {

	abstract void function();
	
}
